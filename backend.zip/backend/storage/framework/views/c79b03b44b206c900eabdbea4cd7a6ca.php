<!DOCTYPE html>
<html lang="pt-BR" x-data="{ sidebarOpen: window.innerWidth >= 1024 }" x-init="
  window.addEventListener('resize', () => {
    if (window.innerWidth >= 1024) sidebarOpen = true;
    else sidebarOpen = false;
  });
">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $__env->yieldContent('title', 'Clínica Fácil'); ?></title>

  
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/favicon/apple-touch-icon.png')); ?>">
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/favicon/favicon-32x32.png')); ?>">
  <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/favicon/favicon-16x16.png')); ?>">
  <link rel="manifest" href="<?php echo e(asset('assets/favicon/site.webmanifest')); ?>">
  <link rel="shortcut icon" href="<?php echo e(asset('assets/favicon/favicon.ico')); ?>" type="image/x-icon">
  <meta name="theme-color" content="#1a5632">

  
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="//unpkg.com/alpinejs" defer></script>
</head>


<body class="flex flex-col min-h-screen bg-gray-100">
  <div class="flex flex-1 overflow-hidden">
    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="flex flex-col flex-1 min-h-screen overflow-y-auto">
      <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <main class="flex-1 p-4 sm:p-6 overflow-y-auto">
        <?php echo $__env->yieldContent('content'); ?>
      </main>
    </div>
  </div>
</body>
</html>
<?php /**PATH /var/www/resources/views/layouts/app.blade.php ENDPATH**/ ?>